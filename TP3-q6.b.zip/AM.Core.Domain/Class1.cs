﻿namespace AM.Core.Domain
{
    public class Class1
    {

    }
}
