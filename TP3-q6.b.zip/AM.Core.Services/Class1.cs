﻿namespace AM.Core.Services
{
    public class Class1
    {

    }
}
