﻿namespace AM.Data
{
    public class Class1
    {

    }
}
